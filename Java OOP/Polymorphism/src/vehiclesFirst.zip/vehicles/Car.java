package vehicles;

public class Car extends Vehicle{
private final static double ADDITIONAL_CONSUMPTION = 0.9;

    protected Car(double fuelQuantity, double fuelConsumptionKM) {
        super(fuelQuantity, fuelConsumptionKM + ADDITIONAL_CONSUMPTION);
    }
}
