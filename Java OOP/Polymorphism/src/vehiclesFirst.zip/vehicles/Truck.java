package vehicles;

public class Truck extends Vehicle {
private static final double ADDITIONAL_CONSUMPTION = 1.6;

    public Truck(double fuelQuantity, double fuelConsumptionKM) {
        super(fuelQuantity, fuelConsumptionKM + ADDITIONAL_CONSUMPTION);
    }


    @Override
    public void refuel(double fuel) {
        super.refuel(fuel * 0.95);
    }


}
