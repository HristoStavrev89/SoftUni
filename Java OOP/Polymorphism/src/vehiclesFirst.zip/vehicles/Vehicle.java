package vehicles;

import java.text.DecimalFormat;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumptionKM;

    protected Vehicle(double fuelQuantity, double fuelConsumptionKM) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumptionKM = fuelConsumptionKM;
    }

    public String drive(double km){
        String result = null;
        double fuelNeeded = km * this.fuelConsumptionKM;

        if (fuelNeeded <= this.fuelQuantity) {
            this.fuelQuantity -= fuelNeeded;

            DecimalFormat format = new DecimalFormat("#.##");

            result = String.format("%s travelled %s km"
            ,this.getClass().getSimpleName()
            ,format.format(km)
            );
        } else {
            result = String.format("%s needs refueling", this.getClass().getSimpleName());
        }
        return result;
    }


    public void refuel(double fuel) {
        this.fuelQuantity += fuel;
    }


    @Override
    public String toString() {
        return String.format("%s: %.2f"
        ,this.getClass().getSimpleName()
        ,this.fuelQuantity);
    }
}
