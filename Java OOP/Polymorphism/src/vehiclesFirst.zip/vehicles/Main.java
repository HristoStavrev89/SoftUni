package vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        String[] carData= scanner.nextLine().split("\\s+");
        Vehicle car = new Car(Double.parseDouble(carData[1]), Double.parseDouble(carData[2]));

        String[] truckData = scanner.nextLine().split("\\s+");
        Vehicle truck = new Truck(Double.parseDouble(truckData[1]), Double.parseDouble(truckData[2]));

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] vehicleData = scanner.nextLine().split("\\s+");

            String command = vehicleData[0];
            String type = vehicleData[1];
            double num = Double.parseDouble(vehicleData[2]);
            if (command.equals("Drive")) {
                if (type.equals("Car")) {
                    System.out.println(car.drive(num));
                } else if (type.equals("Truck")) {
                    System.out.println(truck.drive(num));
                }
            } else if (command.equals("Refuel")) {
                if (type.equals("Car")) {
                    car.refuel(num);
                } else if (type.equals("Truck")) {
                    truck.refuel(num);
                }
            }
        }

        System.out.println(car.toString());
        System.out.println(truck.toString());


    }
}
