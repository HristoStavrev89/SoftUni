package army.enums;

public enum Corp {
    Airforces,
    Marines;


}
