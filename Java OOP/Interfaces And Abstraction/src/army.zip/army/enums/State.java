package army.enums;

public enum State {
    inProgress,
    finished;


}
