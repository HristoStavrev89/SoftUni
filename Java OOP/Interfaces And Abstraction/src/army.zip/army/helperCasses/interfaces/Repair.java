package army.helperCasses.interfaces;

public interface Repair {

    String getName();
    int getHoursWorked();

}
