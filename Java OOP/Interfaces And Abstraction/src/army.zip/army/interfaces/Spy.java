package army.interfaces;

public interface Spy {
    String getCodeNumber();
}
