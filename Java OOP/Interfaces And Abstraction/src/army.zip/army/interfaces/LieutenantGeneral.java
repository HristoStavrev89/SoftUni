package army.interfaces;

public interface LieutenantGeneral {
    void addPrivate(Private soldier);
}
