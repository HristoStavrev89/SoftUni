package army.interfaces;

import army.enums.Corp;

public interface SpecialisedSoldier {
    Corp getCorp();
}
