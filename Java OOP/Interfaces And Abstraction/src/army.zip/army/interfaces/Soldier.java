package army.interfaces;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();
}
