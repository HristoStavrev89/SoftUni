package Google;

public class Children {
    private String childrenName;
    private String childrenBirthDay;


    public Children(String childrenName, String childrenBirthDay) {
        this.childrenName = childrenName;
        this.childrenBirthDay = childrenBirthDay;
    }

    public String getChildrenName() {
        return childrenName;
    }

    public String getChildrenBirthDay() {
        return childrenBirthDay;
    }
}
