package OpinionPoll;

public class Person {
    private String name;
    private int ages;


    public Person (String name, int age) {
        this.name = name;
        this.ages = age;
    }

    public String getName() {
        return name;
    }

    public int getAges() {
        return ages;
    }

//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public void setAges(int ages) {
//        this.ages = ages;
//    }
}
